package edu.alumno.helena.api_rest_bd_pelicula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestBdPeliculaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestBdPeliculaApplication.class, args);
	}

}
