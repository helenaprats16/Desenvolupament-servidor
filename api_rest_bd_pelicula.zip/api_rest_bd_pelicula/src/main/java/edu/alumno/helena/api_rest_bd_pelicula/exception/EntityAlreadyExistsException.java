package edu.alumno.helena.api_rest_bd_pelicula.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

@Data
@Getter
@AllArgsConstructor
@ResponseStatus(HttpStatus.CONFLICT)
public class EntityAlreadyExistsException extends RuntimeException {
    
    private final String errorCode;

    public EntityAlreadyExistsException(String errorCode, String message){
        super(message);
        this.errorCode = errorCode;
    }


}

   