package edu.alumno.helena.api_rest_bd_pelicula;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestBdPeliculaApplicationTests {

	@Test
	void contextLoads() {
	}

}
